﻿using UnityEngine;

namespace Assets.Scripts {
    public class DatanodeProperties : MonoBehaviour {           // these are attributes that show up when we hover over each bubble
        public string TypeInfo;
        public int CountInfo;
    }
}